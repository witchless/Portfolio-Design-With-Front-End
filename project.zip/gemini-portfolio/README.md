--- lang="En"

# 👨‍💻 [Yusuf GOKMEN] - Kişisel Portfolyo Web Sitesi

![Proje Önizlemesi](./img/Preview.png)

## 📖 Proje Hakkında

Bu proje,  insanların yeteneklerini, deneyimlerini ve geçmiş çalışmalarını sergilemek amacıyla tasarladığım kişisel portfolyo web sitesidir. Modern web tasarım prensiplerine sadık kalınarak, tamamen **HTML5**, **CSS3** ve **JavaScript** kullanılarak geliştirilmiştir.

Amacım, temiz kod yapısı ve kullanıcı dostu bir arayüz ile çalışmalarımı profesyonel bir şekilde sunmaktır.

[🌍 Canlı Demo İçin Tıkla](https://project.yusufgokmen.com)

--

## ✨ Özellikler

* **Responsive Tasarım:** Mobil, tablet ve masaüstü cihazlarla tam uyumlu.
* **Modern UI/UX:** Temiz arayüz, yumuşak geçiş efektleri ve animasyonlar.
* **Dinamik Etkileşimler:** JavaScript ile geliştirilmiş menü, filtreleme ve form validasyonları.
* **SEO Dostu:** Anlamsal (Semantic) HTML yapısı.

--

## 🛠️ Kullanılan Teknolojiler

Bu proje aşağıdaki teknolojiler ve araçlar kullanılarak oluşturulmuştur:

* **HTML5:** Sayfa iskeleti ve anlamsal yapı.
* **CSS3:** Stil, Flexbox/Grid yapısı ve animasyonlar.
* **JavaScript (ES6+):** Hareketli arkaplan ve interaktif özellikler.
* **Font Awesome:** İkon setleri için.
* **Google Fonts:** Tipografi için.

--

## 📂 Dosya Yapısı

Projenin genel klasör yapısı şu şekildedir:

```text
/
├── index.html          # Ana HTML dosyası
│── img/                # Görsel Dosyası
├── css/                # Stil içeriği
├── finisher-header.es5.min.js          # JavaScript dosyası
└── README.md           # Proje dokümantasyonu



Bana Ulaşmak İçin;

LinkedIn: https://linkedin.com/in/yusuf-gokmen

Email: gokmeny321@gmail.com

GitHub: https://github.com/witchless

___________________________________________________________________________________________________________________________________________________




--- lang="En"

# 👨‍💻 [Yusuf GOKMEN] - Personal Portfolio Website

![Project Preview](./img/Preview.png)

## 📖 About Project

This project is a personal portfolio website I designed to showcase people's talents, experience, and past work. It was developed entirely using **HTML5**, **CSS3**, and **JavaScript**, adhering to modern web design principles.

My goal is to present my work professionally, with a clean code structure and user-friendly interface.

[🌍 Click for Live Demo](https://project.yusufgokmen.com)

--

## ✨ Features

* **Responsive Design:** Fully compatible with mobile, tablet, and desktop devices.
* **Modern UI/UX:** Clean interface, smooth transition effects, and animations.
* **Dynamic Interactions:** Menu, filtering, and form validations enhanced with JavaScript.
* **SEO Friendly:** Semantic HTML structure.

--

## 🛠️ Technologies Used

This project was created using the following technologies and tools:

* **HTML5:** Page framework and semantic structure.
* **CSS3:** Styling, Flexbox/Grid structure, and animations.
* **JavaScript (ES6+):** Animated backgrounds and interactive features.
* **Font Awesome:** For icon sets.
* **Google Fonts:** For typography.

--

## 📂 File Structure

The general folder structure of the project is as follows:

```text
/
├── index.html # Main HTML file
│── img/ # Image file
├── css/ # Style content
├── finisher-header.es5.min.js # JavaScript file
└── README.md # Project documentation



Contact With Me;

LinkedIn: https://linkedin.com/in/yusuf-gokmen

Email: gokmeny321@gmail.com

GitHub: https://github.com/witchless